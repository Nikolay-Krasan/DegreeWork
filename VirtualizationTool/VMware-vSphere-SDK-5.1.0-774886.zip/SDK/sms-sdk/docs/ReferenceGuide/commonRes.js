var ID_Copyright = "&copy; 2012 VMware, Inc. All rights reserved.";
var ID_VersionInformation = "Revision 10-Sep-2012 &nbsp;|&nbsp; vSphere 5.1 &nbsp;|&nbsp; vSphere vCenter SMS API 3.0";
